library(robCompositions)

# Fun�ao para calcular as frequ�ncias no conjunto de dados
freq = function(alocados){
  if(is.null(alocados)){
    return(0)
  }
  f = NULL
  for (i in 3:ncol(alocados)){
    f <- cbind(f,table(alocados[,1],alocados[,i]))
  }
  return(f)
}
# Fun�ao para calcular as propor��es no conjunto de dados
prop = function(alocados,dig=3){
  p <- cbind(round(freq(alocados)/as.vector(table(alocados[,1])),dig),as.vector(table(alocados[,1])))
  dimnames(p)[[2]][ncol(p)] <- "n"
  return(p)
}
# Fun�ao para construir os vetores que ser�o usados na aloca�ao para cada paciente
vecnew = function(novos){
  f = NULL
  for (i in 2:ncol(novos)){
    f <- cbind(f,table(novos[,1],novos[,i]))
  }
  return(f)
}
# Dist�ncia M�dia (de Aitchison) entre as k componentes de X e Y, ponderada por (p1,...,pk)
aDistP = function(X,Y,ncat=length(X),P=NULL,n=c(0,0),eps=0){
  if(is.null(P)) { P <- rep(1/(length(ncat)+1),(length(ncat)+1)) }
  P <- P/sum(P)
  k <- NULL
  for(i in 1:length(ncat)){
    k<-c(k,rep(1/ncat[i],ncat[i]))
  }
  X <- X+k
  Y <- Y+k
  X <- X/sum(X[1:ncat[1]])
  Y <- Y/sum(Y[1:ncat[1]])
  j <- 1
  d <- 0
  ncat <- cumsum(ncat)
  for(i in 1:(length(ncat))){
    d <- d + P[i]*aDist(X[j:ncat[i]],Y[j:ncat[i]])
    j <- ncat[i]+1
  }
  n1 <- (c(n[1],n[2])+0.5)/sum(n+0.5)
  n2 <- (c(n[2],n[1])+0.5)/sum(n+0.5)
  d <- d + P[length(P)]*aDist(n1,n2)
  limites = c(1e-10,1-(1e-10))
  u1 <- runif(1,limites[1],limites[2])
  u2 <- runif(1,limites[1],limites[2])
  da <- aDist(c(u1,1-u1),c(u2,1-u2))
  return((1-eps)*d + eps*da)
}
# Fun�ao que faz o alocamento de 'novos' em um dos dois grupos, com base nos 'alocados' anteriormente
# 'novos' deve ter o id do paciente na primeira coluna e as vari�veis categoricas que ser�o consideradas nas demais
# 'alocados' deve ter os grupos dos indiv�duo j� alocados na primeira coluna e as demais coluna com as mesmas vari�veis de 'novos'
# P � o peso de cada vari�vel a ser considerada na aloca��o
# eps � o peso da componente aleat�ria na dist�ncia
Aloca = function(novos,alocados=NULL,P=NULL,eps=0,n=FALSE,imprime=FALSE){
  # Garante que todos os n�veis de cada vari�vel (categ�rica) estar�o presentes nos c�lculos
  ncat <- NULL
  for (i in 2:ncol(novos)){
    alocados[,(i+1)] <- factor(alocados[,(i+1)],levels=levels(as.factor(c(as.vector(alocados[,i+1]),as.vector(novos[,i])))))
    novos[,i] <- factor(novos[,i],levels=levels(as.factor(c(as.vector(alocados[,i+1]),as.vector(novos[,i])))))
    # N� de categorias de cada vari�vel
    ncat <- c(ncat,nlevels(novos[,i]))
  }
  g1 <- NULL
  g2 <- NULL
  # Aloca (aleatoriamente) o primeiro paciente caso ningu�m ainda tenha sido alocado
  if(is.null(alocados[1,1])){
    alocados <- cbind((1+rbinom(1,1,0.5)),novos[1,])
    names(alocados)[1] = "Grupo"
    row.names(alocados) = "1"
    alocados[,1] <- factor(alocados[,1],levels=c(1,2))
    ifelse(alocados[1,1]==1,g1<-c(g1,alocados[1,2]),g2<-c(g2,alocados[1,2]))
    if(nrow(novos)>1){ novos <- novos[2:nrow(novos),] }
    else{ novos <- NULL}
  }
  # Tamanho dos grupos
  n <- table(alocados[,1])
  # Vetores de frequencias absolutas dos pacientes j� alocados no dois grupos
  fr <- freq(alocados)
  if(!is.null(novos)){
    # Vetores relativos a cada paciente
    vec <- vecnew(novos)
    # Aloca sequencialmente os novos pacientes
    for (i in 1:nrow(vec)){
      d1 <- aDistP(fr[1,]+vec[i,],fr[2,],ncat,P,n+c(1,0),eps)
      d2 <- aDistP(fr[1,],fr[2,]+vec[i,],ncat,P,n+c(0,1),eps)
      if(d1<d2){
        alocados[(nrow(alocados)+1),] <- c(1,novos[i,])
        g1<-c(g1,novos[i,1])
        n[1]<-n[1]+1
      } else{
        alocados[(nrow(alocados)+1),] <- c(2,novos[i,])
        g2<-c(g2,novos[i,1])
        n[2]<-n[2]+1
      }
      fr <- freq(alocados)
    }
  }
  if(imprime==TRUE){
    cat("Os",length(g1),"pacientes alocados no Grupo 1 foram:",sort(g1),"\n\n")
    cat("Os",length(g2),"pacientes alocados no Grupo 2 foram:",sort(g2),"\n\n")
    cat("Dist�ncia final entre os grupos:",aDistP(fr[1,],fr[2,],ncat,P,n,eps=0),"\n\n")
    print(freq(alocados))
    cat("\n")
    print(round(freq(alocados)/as.vector(table(alocados[,1])),3))
  }
  return(list(dist=aDistP(fr[1,],fr[2,],ncat,P,n,eps=0),alocados=alocados,f=freq(alocados),fr=freq(alocados)/as.vector(table(alocados[,1])) ))
}


novos = read.table("Data.txt", header=TRUE)
set.seed(1)
P=c(1,2,1,2)

a <- Aloca(novos,alocados=NULL,P,eps=0.00,imprime=TRUE)


